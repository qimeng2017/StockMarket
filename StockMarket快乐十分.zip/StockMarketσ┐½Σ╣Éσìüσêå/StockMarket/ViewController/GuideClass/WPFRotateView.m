//
//  WPFRotateView.m
//  01-幸运转盘第二遍
//
//  Created by 王鹏飞 on 16/1/13.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import "WPFRotateView.h"
#import "WPFButton.h"

// 整个转盘的按钮个数
#define kCount 12

// 每个按钮所对应角度
#define kAngle (M_PI * 2 / 12)

@interface WPFRotateView ()
{
    UIButton         *_selBtn;   // 当前被选择的星座按钮
    CADisplayLink    *_link;     // 定时器
}

@property (weak, nonatomic) IBOutlet UIImageView *rotateWheel;
@end

// 图片框默认不与用户交互
// view 默认只支持单点触控，点开mutableTouch 则支持多点触控


@implementation WPFRotateView

// 加载xib文件
+ (instancetype)rotateView {

    return [[[NSBundle mainBundle] loadNibNamed:@"WPFRotateView" owner:nil options:nil] lastObject];
}


// 添加按钮
- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = [UIColor clearColor];
    
    // 默认显示星座
    self.function = @"Astrology";
    
    for (NSInteger i = 0; i < kCount; i++) {
        
        // 实例化按钮
        WPFButton *btn = [WPFButton buttonWithType:UIButtonTypeCustom];
        
        //btn.backgroundColor = [UIColor colorWithRed:arc4random_uniform(256) / 255.0 green:arc4random_uniform(256) / 255.0 blue:arc4random_uniform(256) / 255.0 alpha:1.0];
        
        
        
        // 设置背景图片
        [btn setBackgroundImage:[UIImage imageNamed:@"LuckyRototeSelected"] forState:UIControlStateSelected];
        
        // 添加点击事件
        [btn addTarget:self action:@selector(btnDidClick:) forControlEvents:UIControlEventTouchUpInside];
        
        // 绑定tag
        btn.tag = i;
        
        // 将按钮添加到转盘当中
        [self.rotateWheel addSubview:btn];
        
    }
    
    // 设置按钮图片(内部是循环添加按钮图片，因此要放在循环外面)
    [self setupBtnImg];
    
}

// 设置按钮图片
- (void)setupBtnImg {
    
    [_rotateWheel.subviews enumerateObjectsUsingBlock:^(__kindof WPFButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        // 根据转盘的类别判断按钮的类型
        if ([self.function isEqualToString:@"Animal"]) {
            obj.type = kBtnTypeAnimal;
        } else {
            obj.type = kBtnTypeAstrology;
        }
        
        // 重新设置按钮的图片大小
        [obj imageRectForContentRect:obj.bounds];
        
        // 设置按钮图片
        UIImage *imgNor = [self clipsImgWithImgName:[NSString stringWithFormat:@"Lucky%@", self.function] index:idx];
        UIImage *imgSel = [self clipsImgWithImgName:[NSString stringWithFormat:@"Lucky%@Pressed", self.function] index:idx];
        
        [obj setImage:imgNor forState:UIControlStateNormal];
        [obj setImage:imgSel forState:UIControlStateSelected];
    }];
    
    
}

// 实现星座按钮的点击事件
- (void)btnDidClick:(UIButton *)sender {

    _selBtn.selected = NO;
    
    sender.selected = YES;
    
    _selBtn = sender;
    
}


// 根据图片名称和索引裁剪图片
- (UIImage *)clipsImgWithImgName:(NSString *)name index:(NSInteger)idx {

    // 获取图片
    UIImage *image = [UIImage imageNamed:name];
    
    // 设置frame
    CGFloat imgWidth = image.size.width / kCount;
    CGFloat imgHeight = image.size.height;
    CGFloat imgX = imgWidth * idx;
    
    // 设置缩放比例(Retina屏幕plus 放大三倍， 普通放大两倍， 非retina屏幕一倍)
    CGFloat scale = [UIScreen mainScreen].scale;
    imgWidth *= scale;
    imgHeight *= scale;
    imgX *= scale;
    
    CGImageRef clipImg = CGImageCreateWithImageInRect(image.CGImage, CGRectMake(imgX, 0, imgWidth, imgHeight));
    
    return [UIImage imageWithCGImage:clipImg];
}


// 调整按钮位置
- (void)layoutSubviews {
    
    [super layoutSubviews];
    
    // 设置frame
    CGFloat btnWidth = 68;
    CGFloat btnHeight = 143;
    
    [self.rotateWheel.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        // 设置frame
        obj.bounds = CGRectMake(0, 0, btnWidth, btnHeight);
        obj.center = self.rotateWheel.center;
        
        // 上移
        obj.layer.anchorPoint = CGPointMake(0.5, 1);
        
        // 旋转 分散
        // MakeRotation 相对于原始位置转动一定的角度
        obj.transform = CGAffineTransformMakeRotation(kAngle * idx);
        
    }];
}


// 让转盘开始旋转
- (void)startRotating {
    
    // 如果当前定时器为空，就重新实例化一个
    if (nil == _link) {
        
        // 实例化计时器
        _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(keepRatate)];
        
        // 添加到当前运行循环中
        [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    } else {
        
        // 如果不为空，就关闭暂停
        _link.paused = NO;
    }
}


// 让转盘保持旋转
- (void)keepRatate {
    
    self.rotateWheel.transform = CGAffineTransformRotate(self.rotateWheel.transform, M_PI_4 * 0.01);
    
}


// 开始选号按钮的点击事件
- (IBAction)btnSelNumDidClick:(UIButton *)sender {
    
    // 当前页面不可与用户交互
    self.userInteractionEnabled = NO;
    
    // 暂停计时器
    _link.paused = YES;
    
    // 添加核心动画
    CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    // 隐式代理
    anim.delegate = self;
    
    // 设置基本信息
    CGFloat angle = kAngle * _selBtn.tag;
    
    // 减去这个角度，直接转到合适的地方，而不是再弹回去
    anim.toValue = @(M_PI * 2 * 7 -angle);
    anim.duration = 3.0;
    
    [_rotateWheel.layer addAnimation:anim forKey:nil];
    
}


// 核心动画 执行完毕后调用这个方法
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    
    CGFloat angle = kAngle * _selBtn.tag;
    
    // 这里是为了直接转到正上方
    self.rotateWheel.transform = CGAffineTransformMakeRotation(-angle);
    
    // 利用代理，弹出警告框
    if ([self.delegate respondsToSelector:@selector(didFinishSelNum:)]) {
        [self.delegate didFinishSelNum:self];
    }
    
    
}

@end
