//
//  WPFGuideCell.h
//  02-网易彩票
//
//  Created by 王鹏飞 on 16/1/18.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>

// 制定协议
@protocol WPFGuideCellDelegate <NSObject>

- (void)go2MainVc;

@end


@interface WPFGuideCell : UICollectionViewCell

/** 每个cell 对应的图片 */
@property (nonatomic, strong) UIImage *image;

/** "立即体验"按钮 */
@property (nonatomic, weak) UIButton *btnExperience;

/** "跳过"按钮 */
@property (nonatomic, weak) UIButton *btnJump;

/** 声明代理对象 */
@property (nonatomic, assign) id<WPFGuideCellDelegate> delegate;

@end
