//
//  WPFGuideCell.m
//  02-网易彩票
//
//  Created by 王鹏飞 on 16/1/18.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import "WPFGuideCell.h"
#import "UIView+WPFExtension.h"
@interface WPFGuideCell ()

/** 存放大小文本和广告的图片框 */
@property (nonatomic, weak) UIImageView *imgView;



@end

@implementation WPFGuideCell

// 重写构造方法，这时候还没有self.image
- (instancetype)initWithFrame:(CGRect)frame {

    if (self = [super initWithFrame:frame]) {
        
        // 1. 创建图片框，设置图片
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:self.bounds];
        
        self.imgView = imgView;
        
        [self.contentView addSubview:imgView];
        
        // 2. 创建“立即体验”按钮
        UIButton *btnExperience = [[UIButton alloc] init];
        [btnExperience setImage:[UIImage imageNamed:@"guideStart"] forState:UIControlStateNormal];
        [btnExperience sizeToFit];
        btnExperience.center = CGPointMake(self.width * 0.5, self.height * 0.85);
        btnExperience.hidden = YES;
        self.btnExperience = btnExperience;
        [self.contentView addSubview:btnExperience];
        
        [btnExperience addTarget:self action:@selector(btnDidClick:) forControlEvents:UIControlEventTouchUpInside];
        
        // 3. 创建“跳过”按钮
        UIButton *btnJump = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnJump setTitle:@"跳过" forState:UIControlStateNormal];
        
#warning 有问题：必须全部设置才显示
        btnJump.frame = CGRectMake(self.width - btnJump.width, 10, 100, 40);
        btnJump.x = self.width - btnJump.width;
        
        btnJump.hidden = NO;
        self.btnJump = btnJump;
        [self.contentView addSubview:btnJump];
        
        [btnJump addTarget:self action:@selector(btnDidClick:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return self;
}

- (void)btnDidClick:(UIButton *)sender {

    // 调用代理方法
    if ([self.delegate respondsToSelector:@selector(go2MainVc)]) {
        [self.delegate go2MainVc];
    }
}


// 重写图片的set 方法，赋值给图片框
- (void)setImage:(UIImage *)image {
    _image = image;
    
    self.imgView.image = image;
}


// 最多加载一次（在这里一次也没有加载）
- (void)awakeFromNib {
    
    [super awakeFromNib];
    
    NSLog(@"awakeFromNib");
}

// 只有在这个方法里设置背景色和图片才有效
// 懒加载模式，单元格复用，因此不能在这里设置图片
- (void)layoutSubviews {
    
    NSLog(@"layoutSubviews");
    
    //self.backgroundColor = WPFRandomColor;
}

@end
