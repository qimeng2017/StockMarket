//
//  WPFRotateView.h
//  01-幸运转盘第二遍
//
//  Created by 王鹏飞 on 16/1/13.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WPFRotateView;


// 制定协议
@protocol WPFRotateViewDelegate <NSObject>

- (void)didFinishSelNum:(WPFRotateView *)rotateView;

@end

@interface WPFRotateView : UIView

/** 类方法，快速创建转盘 */
+ (instancetype)rotateView;

/** 对象方法，让转盘开始旋转 */
- (void)startRotating;

/** 设置按钮图片 */
- (void)setupBtnImg;

/** 绑定代理对象 */
@property (nonatomic, assign) id<WPFRotateViewDelegate> delegate;

/** 转盘类别 */
@property (nonatomic, copy) NSString *function;
@end
