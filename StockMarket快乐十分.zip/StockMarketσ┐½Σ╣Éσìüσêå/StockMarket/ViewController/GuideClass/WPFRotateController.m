//
//  WPFRotateController.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/9.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "WPFRotateController.h"
#import "WPFRotateView.h"
#import "UIView+WPFExtension.h"
@interface WPFRotateController ()<WPFRotateViewDelegate>
{
    WPFRotateView *_rotateView;
}


@end

@implementation WPFRotateController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 创建转盘并添加到当前view
    _rotateView = [WPFRotateView rotateView];
    _rotateView.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height * 0.6);
    
    _rotateView.delegate = self;
    
    [self.view addSubview:_rotateView];
    
    // 转盘开始旋转
    [_rotateView startRotating];
    // Do any additional setup after loading the view from its nib.
}
// 实现转盘view 的代理方法
- (void)didFinishSelNum:(WPFRotateView *)rotateView {
    
    
    // 弹出警告框
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"幸运号码" message:@"123333" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
        // 恢复计时
        [_rotateView startRotating];
        
        // 恢复用户交互
        _rotateView.userInteractionEnabled = YES;
        
    }];
    
    [alert addAction:confirm];
    
#warning 延时
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self presentViewController:alert animated:YES completion:nil];
    });
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)shuangseqiuAction:(id)sender {
}
- (IBAction)btnConstellationDidClick:(id)sender {
    _rotateView.function = @"Astrology";
    
    [_rotateView setupBtnImg];
}
- (IBAction)btnZodiacDidClick:(id)sender {
    _rotateView.function = @"Animal";
    
    [_rotateView setupBtnImg];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
