//
//  WPFGuideController.m
//  02-网易彩票
//
//  Created by 王鹏飞 on 16/1/18.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import "WPFGuideController.h"
#import "WPFGuideCell.h"
#import "UIView+WPFExtension.h"
#import "MainViewController.h"
#import "LNNavigationVC.h"
// 随机色
#define WPFRandomColor [UIColor colorWithRed:arc4random_uniform(256) / 255.0 green:arc4random_uniform(256) / 255.0 blue:arc4random_uniform(256) / 255.0 alpha:1.0]
@interface WPFGuideController () <UIScrollViewDelegate, WPFGuideCellDelegate>

/** 存放所有北京图片的数组 */
@property (nonatomic, strong) NSArray *backImgArr;

// 三个图片框
@property (nonatomic, weak) UIImageView *adImgView;
@property (nonatomic, weak) UIImageView *bigTxtImgView;
@property (nonatomic, weak) UIImageView *smallTxtImgView;

@end

static NSString * const refuseIdentifier = @"guideCell";

@implementation WPFGuideController

// 建立流水布局
- (instancetype)init {

    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    
    // 设置每个cell大小
    flowLayout.itemSize = [UIScreen mainScreen].bounds.size;
    
    // 设置滚动方向
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    // 设置最小间距
    flowLayout.minimumLineSpacing = 0;
    
    return [super initWithCollectionViewLayout:flowLayout];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 1. 设置collectionView 的主要特征
    [self setMainFunction];
    
    // 2. 设置子视图
    [self setChildImgView];
    NSLog(@"%@", NSHomeDirectory());
}

// 设置collectionView 的主要特征
- (void)setMainFunction {

    // 1. 设置背景颜色
    self.collectionView.backgroundColor = WPFRandomColor;
    
    // 2. 注册cell
    [self.collectionView registerClass:[WPFGuideCell class] forCellWithReuseIdentifier:refuseIdentifier];
    
    // 3. 取消弹簧效果
    self.collectionView.bounces = NO;
    
    // 4. 设置可以翻页
    self.collectionView.pagingEnabled = YES;
    
    // 5. 取消滚动条
    self.collectionView.showsHorizontalScrollIndicator = NO;
}


// 抽取出设置子视图的方法
- (void)setChildImgView {
    
    // 1. 设置波浪线
    UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideLine"]];
    [imgView sizeToFit];
    imgView.x = -250;
    [self.collectionView addSubview:imgView];
    
    // 2. 设置图片
    UIImageView *adImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guide1"]];
    [adImgView sizeToFit];
    [self.collectionView addSubview:adImgView];
    self.adImgView = adImgView;
    
    // 3. 设置大文本
    UIImageView *bigTxtImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideLargeText1"]];
    [bigTxtImgView sizeToFit];
    bigTxtImgView.y = self.view.height * 0.65;
    [self.collectionView addSubview:bigTxtImgView];
    self.bigTxtImgView = bigTxtImgView;
    
    // 4. 设置小文本
    UIImageView *smallTxtImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"guideSmallText1"]];
    [smallTxtImgView sizeToFit];
    smallTxtImgView.y = self.view.height * 0.75;
    [self.collectionView addSubview:smallTxtImgView];
    self.smallTxtImgView = smallTxtImgView;
}

#pragma mark - 实现数据源方法

// 一共有几组
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

// 每组有几行
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.backImgArr.count;
}

// 每行的具体内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    // 根据标识符去collectionView的缓存区去取
    WPFGuideCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:refuseIdentifier forIndexPath:indexPath];
    
    cell.image = self.backImgArr[indexPath.item];
    
    // 如果是最后一张图片，则设置“立即体验”按钮
//    if (indexPath.item == self.backImgArr.count - 1) {
//        cell.btnExperience.hidden = NO;
//    } else {
//    
//        cell.btnExperience.hidden = YES;
//    }
    cell.btnExperience.hidden = indexPath.item - (self.backImgArr.count - 1);
    
    cell.btnJump.hidden = !cell.btnExperience.hidden;
    
    // 设置cell 的代理对象
    cell.delegate = self;
    
    return cell;
    
}

#pragma mark - 实现代理方法
// 减速完成时调用
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    // 1. 计算页数
    NSInteger page = self.collectionView.contentOffset.x / self.collectionView.width;
    
    // 2. 拼接图片名称
    NSString *adImgName = [NSString stringWithFormat:@"guide%ld", page + 1];
    NSString *bigTxtImgName = [NSString stringWithFormat:@"guideLargeText%ld", page + 1];
    NSString *smallTxtImgName = [NSString stringWithFormat:@"guideSmallText%ld", page + 1];
    
    // 3. 设置给相应图片框
    self.adImgView.image = [UIImage imageNamed:adImgName];
    self.bigTxtImgView.image = [UIImage imageNamed:bigTxtImgName];
    self.smallTxtImgView.image = [UIImage imageNamed:smallTxtImgName];
    
    // 4. 移动图片框
    // 4.1 获取当前偏移值
    CGFloat offsetX = self.collectionView.contentOffset.x;
    
    // 4.2 如果向左滑（即偏移值大于图片框x）
    if (offsetX > self.adImgView.x) {
        self.adImgView.x = self.collectionView.contentOffset.x + self.collectionView.width;
        self.bigTxtImgView.x = self.collectionView.contentOffset.x - self.collectionView.width;
        self.smallTxtImgView.x = self.collectionView.contentOffset.x - self.collectionView.width;
        
        [UIView animateWithDuration:0.3 animations:^{
            self.adImgView.x -= self.collectionView.width;
            self.bigTxtImgView.x += self.collectionView.width;
            self.smallTxtImgView.x += self.collectionView.width;
            
        }];
        
    // 4.3 如果向右滑（即偏移值小于图片框）
    } else {
        self.adImgView.x = self.collectionView.contentOffset.x - self.collectionView.width;
        self.bigTxtImgView.x = self.collectionView.contentOffset.x + self.collectionView.width;
        self.smallTxtImgView.x = self.collectionView.contentOffset.x + self.collectionView.width;
        
        [UIView animateWithDuration:0.3 animations:^{
            self.adImgView.x += self.collectionView.width;
            self.bigTxtImgView.x -= self.collectionView.width;
            self.smallTxtImgView.x -= self.collectionView.width;
            
        }];
    }
    
    // 抽取代码
//    self.adImgView.x = self.collectionView.contentOffset.x + (offsetX - self.adImgView.x) * self.collectionView.width;
//            [UIView animateWithDuration:0.3 animations:^{
//                self.adImgView.x += self.collectionView.width;
//            }];
    
}




#pragma mark - 实现cell 的代理方法
- (void)go2MainVc {
    
    
    // 切换应用程序的主窗口根控制器
    LNNavigationVC *navigate = [[LNNavigationVC alloc]initWithRootViewController:[[MainViewController alloc] init]];
    [UIApplication sharedApplication].keyWindow.rootViewController = navigate;

    
}



#pragma mark - 存放背景图片数组的懒加载
- (NSArray *)backImgArr {

    if (nil == _backImgArr) {
        _backImgArr = [NSArray array];
        
        NSMutableArray *temp = [NSMutableArray array];
        
        // 通过循环加载图片
        for (NSInteger i = 1; i < 5; i++) {
            
            NSString *imgName = [NSString stringWithFormat:@"guide%ldBackground", (long)i];
            UIImage *img = [UIImage imageNamed:imgName];
            
            [temp addObject:img];
        }
        
        _backImgArr = temp;
    }
    return _backImgArr;
}




@end
