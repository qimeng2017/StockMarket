//
//  WPFGuideController.h
//  02-网易彩票
//
//  Created by 王鹏飞 on 16/1/18.
//  Copyright © 2016年 王鹏飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WPFGuideController : UICollectionViewController

@end
