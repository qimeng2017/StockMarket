//
//  HistoryModel.h
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/14.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface HistoryModel : JSONModel
@property (nonatomic, strong) NSString *lottery_date;
@property (nonatomic, strong) NSString *lottery_time;
@property (nonatomic, strong) NSString *lottery_nper;
@property (nonatomic, strong) NSString *lottery_number;
@end
