//
//  MoreTableViewCell.h
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/14.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryModel.h"
@interface MoreTableViewCell : UITableViewCell
- (void)historyModel:(HistoryModel *)model;
@end
