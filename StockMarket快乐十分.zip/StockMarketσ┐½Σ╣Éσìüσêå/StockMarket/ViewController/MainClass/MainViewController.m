//
//  MainViewController.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/9.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "MainViewController.h"
#import "ScrollKLineViewController.h"
#import "WPFRotateController.h"
#import "UserStore.h"
#import "HistoryModel.h"
#import "MoreHistoryVC.h"
#import "ScrollKLineViewController.h"
#import "AwarddataModel.h"
#import "NSDate+Formatter.h"
#import "WebViewController.h"
#import "StatisticalViewController.h"
#import "RoadmapViewController.h"
#import "LNNavigationVC.h"
#import "HistoricalOmissionViewController.h"
#import <AFNetworking.h>
@interface MainViewController ()<UINavigationControllerDelegate>
{
    UILabel  *_lotteryDateLabel;//期数
    UIView   *_ballBgView;
    UILabel  *_blessiLable;
    UIView   *_centerView;
    UILabel  *_versionLable;
    UIButton *_lookMoreBtn;

}
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) NSString *lottory_number;/**<解释*/

@property (nonatomic, strong)AwarddataModel *awarddataModel;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.delegate = self;
    
    self.view.backgroundColor = [UIColor whiteColor];
   self.title = @"广东快乐十分资料大全";
    [self setBasice];
    [[UIDevice currentDevice] setValue:
     [NSNumber numberWithInteger: UIInterfaceOrientationPortrait] forKey:@"orientation"];
   
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UIDevice currentDevice] setValue:
     [NSNumber numberWithInteger: UIInterfaceOrientationPortrait] forKey:@"orientation"];
  NSData *data =  [[NSUserDefaults standardUserDefaults] objectForKey:@"myBusinessCard"];
    double nextTime = 0;
    if (data) {
        AwarddataModel *model = [NSKeyedUnarchiver unarchiveObjectWithData:data];
         nextTime  = [NSDate dateWithString:model.next.awardTime];
        self.awarddataModel = model;
    }
  
    double currentTime = [NSDate currentDate];
    if (currentTime > nextTime) {
        [self AFNetworkReachabilityStatus];
    }
    
}
- (NSMutableArray *)dataArray{
    if (_dataArray == nil) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
//适配
- (void)setBasice{
     self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.scrollView = [[UIScrollView alloc]init];
    [self.view addSubview:self.scrollView];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.and.right.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-KScalwh(0));
    }];
    self.scrollView.alwaysBounceVertical=YES;
    self.scrollView.scrollEnabled=YES;
    self.scrollView.showsVerticalScrollIndicator=NO;
    self.viewContent=[[UIView alloc]init];
    [self.scrollView addSubview:self.viewContent];
    [self.viewContent mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollView);
        make.width.equalTo(self.scrollView);
    }];
    [self createView:self.viewContent];
    if (self.viewContent.subviews.count>0){
        [self.viewContent mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.viewContent.subviews.lastObject).offset(KScalwh(0));
        }];
    }
    
}
-(void)getawarddata{
    
    [[UserStore sharedInstance]getawarddataSucessBlock:^(NSURLSessionDataTask *task, id responseObject) {
        NSDictionary *dict =(NSDictionary *)responseObject;
       AwarddataModel *Model = [[AwarddataModel alloc]initWithDictionary:dict error:nil];
         self.awarddataModel =Model;
        NSLog(@"ddd");
    } failureBlock:^(NSURLSessionDataTask *task, NSError *error) {
        
    }];
}

- (void)createView:(UIView*)contentView
{
    //date
    _lotteryDateLabel = [[UILabel alloc] init];
    _lotteryDateLabel.textColor = [UIColor grayColor];
    _lotteryDateLabel.font = [UIFont systemFontOfSize:18];
    [contentView addSubview:_lotteryDateLabel];
    //ball
    UIImage *ballImage = [UIImage imageNamed:@"ball_red"];
    
    _ballBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), ballImage.size.height)];
    [contentView addSubview:_ballBgView];
    _lookMoreBtn = [[UIButton alloc]init];
    [_lookMoreBtn setTitle:@"查看更多历史开奖记录" forState:UIControlStateNormal];
    [_lookMoreBtn addTarget:self action:@selector(more) forControlEvents:UIControlEventTouchUpInside];
    _lookMoreBtn.backgroundColor = [UIColor colorWithHexString:@"#0ca9ec"];
    [_lookMoreBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [contentView addSubview:_lookMoreBtn];
#define Start_X 20.0f*kScaleW           // 第一个按钮的X坐标
#define Start_Y 180.0f*kScaleW           // 第一个按钮的Y坐标
#define Width_Space 20.0f*kScaleW        // 2个按钮之间的横间距
#define Height_Space 20.0f*kScaleW      // 竖间距
#define Button_Height  120*kScaleW   // 高
#define Button_Width (kScreenWidth - Start_X*2 - Width_Space)/2      // 宽
   
 
        for (int i = 0 ; i < mainConfigBtnList.count; i++) {
            NSDictionary *dict = [mainConfigBtnList objectAtIndex:i];
            NSString *title = [dict objectForKey:@"title"];
            NSString *color = [dict objectForKey:@"color"];
            NSInteger index = i % 2;
            NSInteger page = i / 2;
            
            // 圆角按钮
            UIButton *aBt = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            aBt.tag = i;
            aBt.frame = CGRectMake(index * (Button_Width + Width_Space) + Start_X, page  * (Button_Height + Height_Space)+Start_Y, Button_Width, Button_Height);
            aBt.layer.masksToBounds = YES;
            aBt.layer.cornerRadius = 8;
            aBt.titleLabel.font = [UIFont systemFontOfSize:18];
            aBt.backgroundColor = [UIColor colorWithHexString:color];
            [aBt setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [aBt setTitle:title forState:UIControlStateNormal];
            [aBt addTarget:self action:@selector(abtAction:) forControlEvents:UIControlEventTouchUpInside];
            [contentView addSubview:aBt];
        }
    CGFloat y = Start_Y+Height_Space*2+Button_Height*3+30;
    UILabel *verLable = [[UILabel alloc]initWithFrame:CGRectMake(0, y, kScreenWidth, 20)];
    verLable.textAlignment = NSTextAlignmentCenter;
    verLable.textColor = [UIColor grayColor];
    verLable.text = @"@起梦科技 版权所有";
    verLable.font = [UIFont systemFontOfSize:12];
    [contentView addSubview:verLable];
   
    
}
- (void)more{
    MoreHistoryVC *moreVc = [[MoreHistoryVC alloc]init];
   
    [self m_pushViewController:moreVc];
}
- (void)abtAction:(UIButton *)btn{
    switch (btn.tag) {
        case 0:
        {
            //购买彩票
            WebViewController *webVC = [[WebViewController alloc]initWithURL:[NSURL URLWithString:@"https://caipiao.asopeixun.com:6688/other/caipiao_by"]];
            [self m_pushViewController:webVC];
            
        }
            break;
        
        case 1:{
            //历史遗漏
            HistoricalOmissionViewController *historyOmissionVC = [[HistoricalOmissionViewController alloc]init];
            [self m_pushViewController:historyOmissionVC];
        }
            break;
        case 2:{
            //统计结果
            StatisticalViewController *statistiaclVC = [[StatisticalViewController alloc]init];
            [self m_pushViewController:statistiaclVC];
        }
            break;
        case 3:{
            //路珠分析
            RoadmapViewController *roadMapVC = [[RoadmapViewController alloc]init];
            [self m_pushViewController:roadMapVC];
        }
            break;
        case 4:{
            //走势图
            ScrollKLineViewController *srollKLinVC = [[ScrollKLineViewController alloc]init];
            [self m_pushViewController:srollKLinVC];
        }
            break;
        default:
            break;
    }
}
- (void)m_pushViewController:(UIViewController *)viewController{
   [self.navigationController pushViewController:viewController animated:YES];
}
- (void)customBall
{
    for (UIView *view in _ballBgView.subviews) {
        [view removeFromSuperview];
    }
    
    CGFloat x = 20;
    
    
    
    NSArray *nums = [_lottory_number componentsSeparatedByString:@","];
    NSUInteger count = nums.count;
    
    UIImage *ballImage = [UIImage imageNamed:@"ball_red"];
    x = (kScreenWidth - count*ballImage.size.width-(count-1)*10)/2;
    for (NSInteger index = 0; index < [nums count]; index ++) {
        
        UIButton *ballBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [ballBtn setBackgroundImage:[UIImage imageNamed:@"ball_red"] forState:UIControlStateNormal];
        ballBtn.titleLabel.font = [UIFont systemFontOfSize:13];
        [ballBtn setTitle:[nums objectAtIndex:index] forState:UIControlStateNormal];
        [ballBtn sizeToFit];
        ballBtn.frame = CGRectMake(x, 0, CGRectGetWidth(ballBtn.frame), CGRectGetHeight(ballBtn.frame));
        
        x += CGRectGetWidth(ballBtn.frame) + 10;
        
        [_ballBgView addSubview:ballBtn];
        
    }
    
}
- (void)setAwarddataModel:(AwarddataModel *)awarddataModel{
    NSData*udObject= [NSKeyedArchiver archivedDataWithRootObject:awarddataModel];
    [[NSUserDefaults standardUserDefaults] setObject:udObject forKey:@"myBusinessCard"];
    
    _lottory_number = awarddataModel.current.awardNumbers;
    
    [self headerViewLayout:awarddataModel];
}

- (void)headerViewLayout:(AwarddataModel *)model{
    _lotteryDateLabel.text = [NSString stringWithFormat:@"%@ %@期", model.current.awardTime,model.current.periodNumber];
     [_lotteryDateLabel sizeToFit];
    [_ballBgView sizeToFit];
     CGFloat x = 0, y = 0;
    //date
    x = (kScreenWidth-CGRectGetWidth(_lotteryDateLabel.frame))/2;
     y = 25;
    _lotteryDateLabel.frame = CGRectMake(x, y, CGRectGetWidth(_lotteryDateLabel.frame), CGRectGetHeight(_lotteryDateLabel.frame));
    y = CGRectGetMaxY(_lotteryDateLabel.frame)+10;
    _ballBgView.frame = CGRectMake(0, y, CGRectGetWidth(self.view.frame), CGRectGetHeight(_ballBgView.frame));
    [self customBall];
    x= 20;
    y = CGRectGetMaxY(_ballBgView.frame)+10;
    _lookMoreBtn.frame = CGRectMake(x, y, kScreenWidth-2*x, 50*kScaleW);
    _lookMoreBtn.layer.masksToBounds = YES;
    _lookMoreBtn.layer.cornerRadius = 8;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UINavigationControllerDelegate
// 将要显示控制器
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    // 判断要显示的控制器是否是自己
    BOOL isShowHomePage = [viewController isKindOfClass:[self class]];
    
    [self.navigationController setNavigationBarHidden:isShowHomePage animated:YES];
}
#pragma mark -网络状态监测
- (void)AFNetworkReachabilityStatus{
    __weak MainViewController *weakSelf = self;
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                
                break;
                
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"不可达的网络(未连接)");
                break;
                
            case AFNetworkReachabilityStatusReachableViaWWAN:
                 [weakSelf getawarddata];
                break;
                
            case AFNetworkReachabilityStatusReachableViaWiFi:
                [weakSelf getawarddata];
                
                NSLog(@"wifi的网络");
                break;
            default:
                break;
        }
    }];
    [manager startMonitoring];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
