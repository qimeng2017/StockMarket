//
//  HistoricalOmissionViewController.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/16.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HistoricalOmissionViewController.h"
#import "HistoryOmissScrollView.h"
#import "UserStore.h"
#import "HistoryOmissionModel.h"
#import "HistoryHeaderBtnView.h"
@interface HistoricalOmissionViewController ()
@property (nonatomic, strong)HistoryOmissScrollView *histroyScrollView;
@property (nonatomic, strong)NSMutableArray *dataArray;
@end

@implementation HistoricalOmissionViewController
- (NSMutableArray *)dataArray{
    if (_dataArray == nil) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.title = @"历史遗漏";
    [self initUI];
    
}
- (void)initUI{
    HistoryHeaderBtnView *headerBtnView = [[HistoryHeaderBtnView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 40) titles:@[@"大小",@"单双"] clickBlick:^(NSInteger index) {
        [self getBallstat:index];
    }];
    [self.view addSubview:headerBtnView];
    _histroyScrollView = [[HistoryOmissScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headerBtnView.frame), kScreenWidth, CGRectGetHeight(self.view.frame)-CGRectGetHeight(headerBtnView.frame))];
    [self.view addSubview:_histroyScrollView];
}
- (void)getBallstat:(NSInteger)index{
    [SVProgressHUD showWithStatus:@"Loading..."];
    if (self.dataArray.count > 0) {
        [_dataArray removeAllObjects];
    }
   [[UserStore sharedInstance]ballstatSucessBlock:^(NSURLSessionDataTask *task, id responseObject) {
       NSArray *itemArray = [responseObject objectForKey:@"itemArray"];
       for (NSDictionary *dict in itemArray) {
           HistoryOmissionModel *model = [[HistoryOmissionModel alloc]initWithDictionary:dict error:nil];
           [self.dataArray addObject:model];
       }
       dispatch_async(dispatch_get_main_queue(), ^{
           [_histroyScrollView reloadScrollViewWithDays:_dataArray index:index];
           [SVProgressHUD dismissWithDelay:1];
       });
   } failureBlock:^(NSURLSessionDataTask *task, NSError *error) {
       
   }];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [SVProgressHUD dismiss];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
