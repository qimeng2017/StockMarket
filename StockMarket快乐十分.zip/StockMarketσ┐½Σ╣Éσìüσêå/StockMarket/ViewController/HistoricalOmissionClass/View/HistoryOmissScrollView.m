//
//  HistoryOmissScrollView.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/16.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HistoryOmissScrollView.h"
#import "HistoryOmissionTableView.h"

@interface HistoryOmissScrollView ()
@property (nonatomic, strong) HistoryOmissionTableView *historyTableView;
@end
@implementation HistoryOmissScrollView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
         [self setupKLinePlotView];
    }
    return self;
}
- (void)setupKLinePlotView{
    self.contentSize = CGSizeMake(historyDateWidth+historyNumberWidth*16, 0);
    UIView *topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.contentSize.width, 30)];
    topView.backgroundColor = [UIColor colorWithHexString:@"#0ca9ec"];
    [self addSubview:topView];
    UILabel *dateLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, historyDateWidth, CGRectGetHeight(topView.frame))];
    dateLable.textColor = [UIColor whiteColor];
    dateLable.font = [UIFont systemFontOfSize:14];
    dateLable.textAlignment = NSTextAlignmentCenter;
    dateLable.text = @"日期";
    [topView addSubview:dateLable];
    NSArray *ballArray = @[@"第一球",@"第二球",@"第三球",@"第四球",@"第五球",@"第六球",@"第七球",@"第八球"];
    for (NSInteger i = 0; i < ballArray.count; i++) {
        NSString *ballName = ballArray[i];
        UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(historyDateWidth+(historyNumberWidth*2)*i, 0, historyNumberWidth*2, CGRectGetHeight(topView.frame))];
        lable.textColor = [UIColor whiteColor];
        lable.font = [UIFont systemFontOfSize:14];
        lable.text = ballName;
        lable.textAlignment = NSTextAlignmentCenter;
        [topView addSubview:lable];
        
    }
    UIView *centerView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(topView.frame), self.contentSize.width, 30)];
    centerView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    [self addSubview:centerView];
    CGFloat space = 0;
    CGFloat width = historyNumberWidth-4;
    if (CGRectGetHeight(centerView.frame)>width) {
        space = (CGRectGetHeight(centerView.frame)-width)/2;
    }else{
        space = (width -CGRectGetHeight(centerView.frame))/2;
    }
    for (NSInteger i = 0; i<16; i++) {
        UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(historyDateWidth+(width+space)*i, space, width, width)];
        lable.textColor = [UIColor whiteColor];
        lable.font = [UIFont systemFontOfSize:14];
        lable.layer.masksToBounds = YES;
        lable.layer.cornerRadius = width/2;
        lable.tag = i+16;
        if (i%2==0) {
          lable.text = @"大";
            lable.backgroundColor = [UIColor colorWithHexString:@"#df0e09"];
        }else{
          lable.text = @"小";
            lable.backgroundColor = [UIColor colorWithHexString:@"#9b83ff"];
        }
        
        lable.textAlignment = NSTextAlignmentCenter;
        [centerView addSubview:lable];
    }
    _historyTableView = [[HistoryOmissionTableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(centerView.frame), self.contentSize.width, CGRectGetHeight(self.frame)-CGRectGetHeight(centerView.frame)-CGRectGetHeight(topView.frame)) style:UITableViewStylePlain];
    [self addSubview:_historyTableView];
    
}
- (void)reloadScrollViewWithDays:(NSArray *)items index:(NSInteger)index{
    for (NSInteger i = 0; i<16; i++) {
        UILabel *label = (UILabel *)[self viewWithTag:i+16];
        if (i%2==0) {
            if (index == 0) {
                label.text = @"大";
            }else{
                label.text = @"单";
            }
        }else{
            if (index == 0) {
                label.text = @"小";
            }else{
                label.text = @"双";
            }
        }
    }
    [_historyTableView reloadTableViewWithDays:items index:index];
}
@end
