//
//  HistoryOmissionTableView.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/16.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HistoryOmissionTableView.h"
#import "HistoryOmissionCell.h"
#import "HistoryOmissionModel.h"
static NSString *historyCellReuseIdentifier = @"historyCellReuseIdentifier";
@interface HistoryOmissionTableView ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)NSArray *historyArray;
@property (nonatomic, assign)NSInteger selectedIndex;
@end
@implementation HistoryOmissionTableView

-(instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    if (self = [super initWithFrame:frame style:style]) {
        self.dataSource = self;
        self.delegate = self;
       // self.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        self.backgroundColor = [UIColor whiteColor];
        self.tableFooterView = [[UIView alloc]init];
        self.rowHeight = historyCellHeight;
        //[self registerClass:[UITableViewCell class] forCellReuseIdentifier:RoadMapCellReuseIdentifier];
    }
    return self;
}
#pragma mark - tableView的数据源方法

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _historyArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HistoryOmissionCell *cell = [tableView dequeueReusableCellWithIdentifier:historyCellReuseIdentifier];
    if (cell==nil) {
        cell = [[HistoryOmissionCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:historyCellReuseIdentifier];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor whiteColor];
    if (_historyArray.count > indexPath.row) {
        HistoryOmissionModel *model = [_historyArray objectAtIndex:indexPath.row];
        [cell setHistorymodel:model index:_selectedIndex];
    }
    
    return cell;
}
- (void)reloadTableViewWithDays:(NSArray *)items index:(NSInteger)index{
    _historyArray = items;
    _selectedIndex = index;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self reloadData];
    });
}
@end
