//
//  HistoryOmissionCell.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/16.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "HistoryOmissionCell.h"

@interface HistoryOmissionCell ()
@property (nonatomic, strong)UILabel *dateLable;
@end
@implementation HistoryOmissionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initUI];
        
    }
    return self;
}
- (void)initUI{
    _dateLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, historyDateWidth, CGRectGetHeight(self.frame))];
    _dateLable.textColor = [UIColor blackColor];
    _dateLable.font = [UIFont systemFontOfSize:14];
    _dateLable.textAlignment = NSTextAlignmentCenter;
    _dateLable.text = @"20170709";
    [self addSubview:_dateLable];
    CGFloat W_space = 0,H_space = 0;
    CGFloat width = historyNumberWidth-4;
    W_space = (30-width)/2;
    H_space = (historyCellHeight - width)/2;
    for (NSInteger i = 0; i<16; i++) {
        UILabel *lable = [[UILabel alloc]initWithFrame:CGRectMake(historyDateWidth+(width+W_space)*i, H_space, width, width)];
        lable.tag = i+100;
        lable.textColor = [UIColor whiteColor];
        lable.font = [UIFont systemFontOfSize:14];
        lable.layer.masksToBounds = YES;
        lable.layer.cornerRadius = width/2;
        if (i%2==0) {
            lable.text = @"大";
            lable.backgroundColor = [UIColor colorWithHexString:@"#df0e09"];
        }else{
            lable.text = @"小";
            lable.backgroundColor = [UIColor colorWithHexString:@"#9b83ff"];
        }
        
        lable.textAlignment = NSTextAlignmentCenter;
        [self addSubview:lable];
    }
}
- (void)setHistorymodel:(HistoryOmissionModel *)model index:(NSInteger)index{
    NSString *text = [model.date stringByReplacingOccurrencesOfString:@"-" withString:@""];
    _dateLable.text = text;
    for (NSInteger i = 0; i<model.data.count; i++) {
        NSDictionary *dict = [model.data objectAtIndex:i];
        NSNumber *bigNumber = [dict objectForKey:@"big"];
        NSNumber *smallNumber = [dict objectForKey:@"small"];
        NSString *big = [NSString stringWithFormat:@"%@",bigNumber];
        NSString *small = [NSString stringWithFormat:@"%@",smallNumber];
        NSNumber *oddNumber = [dict objectForKey:@"odd"];
        NSString *odd = [NSString stringWithFormat:@"%@",oddNumber];
        NSNumber *evenNumber = [dict objectForKey:@"even"];
        NSString *even = [NSString stringWithFormat:@"%@",evenNumber];
        UILabel *lable0 = (UILabel *)[self viewWithTag:i+100];
        
        UILabel *label1 = (UILabel *)[self viewWithTag:i+101];
        if (index == 0) {
            lable0.text = big;
            label1.text = small;
        }else{
            lable0.text = odd;
            label1.text = even;
        }
        
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
