//
//  RoadMapCell.h
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/15.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoadMapModel.h"
@interface RoadMapCell : UITableViewCell
- (void)roadMapModel:(RoadMapModel *)model;
@end
