//
//  WebViewController.m
//  StockMarket
//
//  Created by 邹壮壮 on 2017/3/15.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "WebViewController.h"
#import "HRWebview.h"
#import "HRFlashLable.h"
@interface WebViewController ()<HRWebviewDelegate>
@property (nonatomic, strong)HRWebview *webView;
@property (nonatomic, strong) HRFlashLable     *tipFlashLable;
@property (nonatomic, strong)NSURL *aUrl;
@end

@implementation WebViewController
- (instancetype)initWithURL:(NSURL *)url
{
    if (self = [super init]) {
        self.aUrl = url;
     
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self setInitUI];
    // Do any additional setup after loading the view.
}
- (void)viewDidAppear:(BOOL)animated
{
    
    [super viewDidAppear:animated];
    NSLog(@"viewDidAppear");
    NSURLRequest *request = [NSURLRequest requestWithURL:self.aUrl];
    [_webView loadRequest:request];
    
}
- (void)setInitUI{
    
    if (_webView == nil) {
        HRWebview *webView = [[HRWebview alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, CGRectGetHeight(self.view.frame))];
        
        webView.delegate = self;
        webView.showsPageTitleInNavigationBar = YES;
        [self.view addSubview:webView];
        _webView = webView;
    }
      [self.view addSubview:self.tipFlashLable];
}
- (HRFlashLable *)tipFlashLable{
    if (_tipFlashLable == nil) {
        _tipFlashLable = [[HRFlashLable alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth/2, 80)];
        _tipFlashLable.text = @"正在努力加载中!";
        _tipFlashLable.center = CGPointMake(kScreenWidth/2, SCREEN_HEIGHT/2);
        _tipFlashLable.textColor = [UIColor grayColor];
        _tipFlashLable.font = [UIFont systemFontOfSize:20];
        _tipFlashLable.haloColor = [UIColor redColor];
        _tipFlashLable.haloWidth = 0.8;
        _tipFlashLable.haloDuration = 2;
        _tipFlashLable.numberOfLines = 2;
        _tipFlashLable.textAlignment = NSTextAlignmentCenter;
    }
    return _tipFlashLable;
}
#pragma mark - UIWebView delegate
- (void)zlcwebViewDidStartLoad:(HRWebview *)webview{
    if (self.tipFlashLable) {
        [self.tipFlashLable removeFromSuperview];
    }
}
- (void)zlcwebView:(HRWebview *)webview didFinishLoadingURL:(NSURL *)URL{
    
}
- (void)zlcwebView:(HRWebview *)webview shouldStartLoadWithURL:(NSURL *)URL{
    
}
- (void)zlcwebView:(HRWebview *)webview didFailToLoadURL:(NSURL *)URL error:(NSError *)error{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
