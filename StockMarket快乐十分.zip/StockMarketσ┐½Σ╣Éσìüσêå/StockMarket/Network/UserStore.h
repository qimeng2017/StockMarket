//
//  UserStore.h
//  LotteryNews
//
//  Created by 邹壮壮 on 2016/12/23.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void(^sucessCompleteBlock)(NSURLSessionDataTask *task, id responseObject);

typedef void(^failureCompleteBlock)(NSURLSessionDataTask *task, NSError * error);

@interface UserStore : NSObject
+ (UserStore *)sharedInstance;
-(void)getHistorySucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
- (void)getNumbertrenddata:(NSInteger)ball SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
- (void)getawarddataSucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
//路珠分析
- (void)getRoadBeadAnalysis:(NSInteger)type SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
//统计结果
- (void)getstatisticalResult:(NSInteger)type SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
//历史遗漏
- (void)ballstatSucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock;
@end


