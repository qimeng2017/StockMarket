//
//  UserStore.m
//  LotteryNews
//
//  Created by 邹壮壮 on 2016/12/23.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "UserStore.h"
#import "HRNetworkTools.h"

#import "NSDate+Formatter.h"
#import "HistoryModel.h"
@implementation UserStore
+ (UserStore *)sharedInstance
{
    static UserStore *_sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[UserStore alloc] init];
    });
    
    return _sharedInstance;
}
-(void)getHistorySucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *current = [NSString stringWithFormat:@"%@",[NSDate localeDate0_0]];
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/history?dateData=%@",LOTTERY_HOST_NAME,current];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *error = [responseObject objectForKey:@"error"];
        if (!error||[error isEqualToString:@""]) {
            NSMutableArray *dataArray = [NSMutableArray array];
            NSArray *itemArray = [responseObject objectForKey:@"itemArray"];
            for (NSArray *items in itemArray) {
                HistoryModel *model = [[HistoryModel alloc]init];
                model.lottery_date = items[0];
                model.lottery_time = items[1];
                model.lottery_nper = items[2];
                model.lottery_number = items[3];
                [dataArray addObject:model];
            }
            sucesBlock(task,dataArray);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
//走势图
- (void)getNumbertrenddata:(NSInteger)ball SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *ballNumber = [NSString stringWithFormat:@"%ld",ball];
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/numbertrenddata?ball=%@",LOTTERY_HOST_NAME,ballNumber];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucesBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
//当前期数开奖号码
- (void)getawarddataSucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/getawarddata",LOTTERY_HOST_NAME];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucesBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
//路珠分析
- (void)getRoadBeadAnalysis:(NSInteger)type SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *statisticalType = @"";
    if (type==0) {
        statisticalType = @"bigorsmallroadmap";
    }else if(type == 1){
        statisticalType = @"oddorevenroadmap";
    }else if(type==2){
        statisticalType = @"totalroadmap";
    }else if(type == 3){
        statisticalType = @"longhuroadmap";
    }else if(type==4){
        statisticalType = @"zhongfabairoadmap";
    }else if(type==5){
        statisticalType = @"positionroadmap";
    }else if(type == 6){
        statisticalType = @"mergeroadmap";
    }else if(type==7){
        statisticalType = @"mantissaroadmap";
    }
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/%@",LOTTERY_HOST_NAME,statisticalType];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucesBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
//统计结果
- (void)getstatisticalResult:(NSInteger)type SucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *statisticalType = @"";
    if (type==0) {
        statisticalType = @"bothsidesanalysis";
    }else if(type == 1){
        statisticalType = @"numberdaystat";
    }else{
        statisticalType = @"twofacedaystat";
    }
   
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/%@",LOTTERY_HOST_NAME,statisticalType];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucesBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
//历史遗漏
- (void)ballstatSucessBlock:(sucessCompleteBlock)sucesBlock failureBlock:(failureCompleteBlock)failureBlock{
    NSString *url = [NSString stringWithFormat:@"%@/api/gdkl10/ballstat",LOTTERY_HOST_NAME];
    [[HRNetworkTools sharedNetworkTools]GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucesBlock(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failureBlock(task,error);
    }];
}
@end
